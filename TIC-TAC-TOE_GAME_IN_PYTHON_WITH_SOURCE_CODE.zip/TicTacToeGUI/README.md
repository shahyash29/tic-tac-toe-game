# TicTacToeGUI
# How To install and use in linux

type in terminal :

> dpkg -i python3-tictactoe_2.0.deb

and then, type in terminal:

> tictactoe
# How To use in Windows
first you need to install python 3 and then run the program on cmd with command:
> <i>py TicTacToe.py</i>
